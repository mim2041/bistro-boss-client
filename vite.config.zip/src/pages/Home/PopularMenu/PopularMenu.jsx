import SectionTitle from "../../../components/SectionTitle/SectionTitle";


const PopularMenu = () => {
    return (
        <section>
            <SectionTitle
                heading="Popular Items"
                subHeading={"From Our Menu"}
            ></SectionTitle>
        </section>
    );
};

export default PopularMenu;