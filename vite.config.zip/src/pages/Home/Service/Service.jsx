// import service from '../../../assets/home/chef-service.jpg';
import './Service.css'

const Service = () => {
    return (
        <div className='service my-12 bg-blue-500'>
            <div className='inner-service p-12'>
                <h1 className='text-5xl uppercase text-center'>Bistro Boss</h1>
                <p className='w-3/5 text-center mx-auto'>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Fugit maxime enim quam delectus culpa veritatis iste? Sint recusandae expedita ea vitae perferendis quos aspernatur voluptas maxime harum nisi minima facilis, voluptatem exercitationem? Quisquam, totam beatae non officiis tenetur.</p>
            </div>
        </div>
    );
};

export default Service;